package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.ServicoBO;
import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("ServicoDetalhe")
@RolesAllowed("ADM")
public class ServicoDetalheController {

    @Inject
    ServicoBO servicoBO;

    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public Response buscar(@QueryParam("nome") String nome) {
        ServicoDTO servico = (nome == null) ? null : servicoBO.buscarPorNome(nome);
        if (servico == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        return Response.ok(servico).build();
    }
}