package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.bo.LogAuditoriaBO;
import br.edu.ifg.luziania.pw.model.dto.AutenticacaoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("LoginADM")
@PermitAll
public class LoginADMController {

    @Inject
    UsuarioBO usuarioBO;

    @Inject
    LogAuditoriaBO auditoriaBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance loginADM();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance loginADMPage() {
        return LoginADMController.Template.loginADM();
    }

    @POST
    @Path("autenticar")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response autenticar(AutenticacaoDTO dto) {
        return usuarioBO.autenticarADM(dto.getIdentificador(), dto.getSenha());
    }
}