package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.ServicoDAO;
import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import br.edu.ifg.luziania.pw.model.entity.Servico;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import br.edu.ifg.luziania.pw.model.dto.ExclusaoServicoDTO;
import br.edu.ifg.luziania.pw.model.entity.Usuario;
import java.util.List;

@RequestScoped
public class ServicoBO {

    @Inject
    ServicoDAO dao;

    @Inject
    LogAuditoriaBO auditoriaBO;

    @Inject
    UsuarioBO usuarioBO;

    @Transactional
    public Response salvar(ServicoDTO dto) {
        if (dto.getNome() == null || dto.getNome().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        Servico entity = new Servico(dto);

        if (entity.getId() == null) {
            dao.insert(entity);
            dto.setId(entity.getId());
            auditoriaBO.registrar("Serviço cadastrado: " + entity.getNome(), "ADM");
        } else {
            // se não veio foto nova, mantém a que já está no banco
            if (dto.getImagem() == null || dto.getImagem().isEmpty()) {
                Servico existente = dao.buscarPorId(entity.getId());
                if (existente != null) {
                    entity.setImagem(existente.getImagem());
                }
            }
            dao.update(entity);
            auditoriaBO.registrar("Serviço atualizado: " + entity.getNome(), "ADM");
        }

        dto.setImagem("");
        return Response.ok(dto).build();
    }

    // EXCLUIR — só apaga se vier o ID e a senha de um ADM de verdade
    @Transactional
    public Response excluir(ExclusaoServicoDTO dto) {
        if (dto == null || dto.getServicoId() == null) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        // primeiro confere o administrador (assim quem não é ADM nem descobre se o serviço existe)
        Usuario adm = usuarioBO.validarADM(dto.getAdminEmail(), dto.getSenha());
        if (adm == null) {
            auditoriaBO.registrar("Exclusão de serviço negada (ID do serviço: " + dto.getServicoId()
                    + ") - e-mail/senha de ADM inválidos", dto.getAdminEmail());
            return Response.status(Response.Status.UNAUTHORIZED).build();
        }

        Servico servico = dao.buscarPorId(dto.getServicoId());
        if (servico == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }

        String nome = servico.getNome();
        dao.delete(servico);
        auditoriaBO.registrar("Serviço excluído: " + nome, adm.getEmail());

        return Response.ok().build();
    }

    public List<ServicoDTO> listarTodos() {
        return dao.listarTodos();
    }

    public ServicoDTO buscarPorNome(String nome) {
        return dao.buscarPorNome(nome);
    }

    public int contar() {
        return dao.listarTodos().size();
    }
}