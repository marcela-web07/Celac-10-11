package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class ExclusaoServicoDTO {
    private Integer servicoId;
    private String adminEmail;
    private String senha;

    //construtor vazio
    public ExclusaoServicoDTO() {
        servicoId = null;
        adminEmail = "";
        senha = "";
    }

    //construtor completo
    public ExclusaoServicoDTO(Integer servicoId, String adminEmail, String senha) {
        this.servicoId = servicoId;
        this.adminEmail = adminEmail;
        this.senha = senha;
    }

    //get e set
    public Integer getServicoId() { return servicoId; }
    public void setServicoId(Integer servicoId) { this.servicoId = servicoId; }

    public String getAdminEmail() { return adminEmail; }
    public void setAdminEmail(String adminEmail) { this.adminEmail = adminEmail; }

    public String getSenha() { return senha; }
    public void setSenha(String senha) { this.senha = senha; }
}