package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.entity.Agendamento;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;

@RequestScoped
public class AgendamentoDAO {

    @Inject
    EntityManager entityManager;

    public void insert(Agendamento entity) {
        entityManager.persist(entity);
    }

    public void update(Agendamento entity) {
        entityManager.merge(entity);
    }

    public void delete(Agendamento entity) {
        entityManager.remove(entity);
    }

    public Agendamento buscarPorId(Integer id) {
        return entityManager.find(Agendamento.class, id);
    }

    public List<AgendamentoDTO> listarTodos() {
        //language=jpql
        String jpql = "select new br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO(" +
                "a.id, a.paciente, a.procedimento, a.data, a.horario, a.observacoes, a.emailUsuario, a.status) " +
                "from Agendamento a";
        return entityManager.createQuery(jpql, AgendamentoDTO.class).getResultList();
    }

    public List<AgendamentoDTO> listarPorEmail(String email) {
        //language=jpql
        String jpql = "select new br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO(" +
                "a.id, a.paciente, a.procedimento, a.data, a.horario, a.observacoes, a.emailUsuario, a.status) " +
                "from Agendamento a where a.emailUsuario = :email and a.status = 'ATIVO'";
        return entityManager.createQuery(jpql, AgendamentoDTO.class)
                .setParameter("email", email)
                .getResultList();
    }

    // horários já ocupados numa data (só agendamentos ATIVOS)
    public List<String> listarHorariosOcupados(String data) {
        //language=jpql
        String jpql = "select a.horario from Agendamento a where a.data = :data and a.status = 'ATIVO'";
        return entityManager.createQuery(jpql, String.class)
                .setParameter("data", data)
                .getResultList();
    }

    // já existe alguém ATIVO nessa data e horário? (idIgnorar = o próprio agendamento, se estiver sendo atualizado)
    public boolean existeAtivo(String data, String horario, Integer idIgnorar) {
        //language=jpql
        String jpql = "select count(a) from Agendamento a " +
                "where a.data = :data and a.horario = :horario and a.status = 'ATIVO' and a.id <> :id";
        Long total = entityManager.createQuery(jpql, Long.class)
                .setParameter("data", data)
                .setParameter("horario", horario)
                .setParameter("id", idIgnorar == null ? -1 : idIgnorar)
                .getSingleResult();
        return total > 0;
    }
}