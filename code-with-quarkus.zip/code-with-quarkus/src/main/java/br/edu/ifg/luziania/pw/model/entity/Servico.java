package br.edu.ifg.luziania.pw.model.entity;

import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import jakarta.persistence.*;

@Entity
@Table(name = "servico")
public class Servico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nome;

    @Column(length = 2000)
    private String descricao;

    private Double valor;

    private String duracao;

    @Column(length = 1000)
    private String beneficios;

    @Column(length = 500)
    private String recomendacao;

    @Column(columnDefinition = "text")
    private String imagem;

    public Servico() {
    }

    public Servico(ServicoDTO dto) {
        this.id = dto.getId();
        this.nome = dto.getNome();
        this.descricao = dto.getDescricao();
        this.valor = dto.getValor();
        this.duracao = dto.getDuracao();
        this.beneficios = dto.getBeneficios();
        this.recomendacao = dto.getRecomendacao();
        this.imagem = dto.getImagem();
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public Double getValor() { return valor; }
    public void setValor(Double valor) { this.valor = valor; }

    public String getDuracao() { return duracao; }
    public void setDuracao(String duracao) { this.duracao = duracao; }

    public String getBeneficios() { return beneficios; }
    public void setBeneficios(String beneficios) { this.beneficios = beneficios; }

    public String getRecomendacao() { return recomendacao; }
    public void setRecomendacao(String recomendacao) { this.recomendacao = recomendacao; }

    public String getImagem() { return imagem; }
    public void setImagem(String imagem) { this.imagem = imagem; }
}