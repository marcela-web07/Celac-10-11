package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class ServicoDTO {
    private Integer id;
    private String nome;
    private String descricao;
    private Double valor;
    private String duracao;
    private String beneficios;
    private String recomendacao;
    private String imagem;

    //construtor vazio
    public ServicoDTO() {
        id = null;
        nome = "";
        descricao = "";
        valor = 0.0;
        duracao = "";
        beneficios = "";
        recomendacao = "";
        imagem = "";
    }

    //construtor completo com id (usado pela query JPQL do ServicoDAO)
    public ServicoDTO(Integer id, String nome, String descricao, Double valor,
                      String duracao, String beneficios, String recomendacao, String imagem) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.valor = valor;
        this.duracao = duracao;
        this.beneficios = beneficios;
        this.recomendacao = recomendacao;
        this.imagem = imagem;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }

    public String getDescricao() { return descricao; }
    public void setDescricao(String descricao) { this.descricao = descricao; }

    public Double getValor() { return valor; }
    public void setValor(Double valor) { this.valor = valor; }

    public String getDuracao() { return duracao; }
    public void setDuracao(String duracao) { this.duracao = duracao; }

    public String getBeneficios() { return beneficios; }
    public void setBeneficios(String beneficios) { this.beneficios = beneficios; }

    public String getRecomendacao() { return recomendacao; }
    public void setRecomendacao(String recomendacao) { this.recomendacao = recomendacao; }

    public String getImagem() { return imagem; }
    public void setImagem(String imagem) { this.imagem = imagem; }
}