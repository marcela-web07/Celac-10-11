package br.edu.ifg.luziania.pw.filtro;

import jakarta.annotation.security.PermitAll;
import jakarta.annotation.security.RolesAllowed;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ResourceInfo;
import jakarta.ws.rs.core.Response;
import org.eclipse.microprofile.jwt.JsonWebToken;
import org.jboss.resteasy.reactive.server.ServerRequestFilter;

import java.lang.reflect.Method;
import java.net.URI;
import java.util.List;
import java.util.Optional;
import java.util.Set;

@ApplicationScoped
public class RequestFilter {

    @Inject
    JsonWebToken jwt;

    // DESLIGADO: tire o // da linha abaixo quando as chaves estiverem prontas
    @ServerRequestFilter
    public Optional<Response> filtrarRequisicao(ContainerRequestContext requisicao, ResourceInfo recurso) {

        // quais perfis a rota exige? (null = rota livre)
        String[] papeis = papeisExigidos(recurso);
        if (papeis == null) {
            return Optional.empty();
        }

        // o token tem um dos perfis exigidos: deixa passar
        if (temAlgumPapel(papeis)) {
            return Optional.empty();
        }

        // sem permissão. Página (o navegador pede HTML): manda para o login certo
        String aceita = requisicao.getHeaderString("Accept");
        boolean ehPagina = "GET".equals(requisicao.getMethod()) && aceita != null && aceita.contains("text/html");
        if (ehPagina) {
            String login = List.of(papeis).contains("CLIENTE") ? "/Login" : "/LoginADM";
            return Optional.of(Response.seeOther(URI.create(login)).build());
        }

        // ação (fetch): 401 se não está logado, 403 se está logado mas não tem permissão
        int status = jwt.getName() == null ? 401 : 403;
        return Optional.of(Response.status(status).build());
    }

    // lê @PermitAll / @RolesAllowed: o método manda mais que a classe
    private String[] papeisExigidos(ResourceInfo recurso) {
        Method metodo = recurso.getResourceMethod();

        if (metodo.isAnnotationPresent(PermitAll.class)) {
            return null;
        }
        RolesAllowed noMetodo = metodo.getAnnotation(RolesAllowed.class);
        if (noMetodo != null) {
            return noMetodo.value();
        }
        RolesAllowed naClasse = recurso.getResourceClass().getAnnotation(RolesAllowed.class);
        return naClasse != null ? naClasse.value() : null;
    }

    private boolean temAlgumPapel(String[] papeis) {
        Set<String> grupos = jwt.getGroups();
        if (jwt.getName() == null || grupos == null) {
            return false;
        }
        for (String papel : papeis) {
            if (grupos.contains(papel)) {
                return true;
            }
        }
        return false;
    }
}