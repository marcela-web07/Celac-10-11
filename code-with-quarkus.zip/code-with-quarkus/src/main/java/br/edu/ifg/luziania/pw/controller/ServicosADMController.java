package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.ServicoBO;
import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import br.edu.ifg.luziania.pw.model.dto.ExclusaoServicoDTO;

import java.util.List;

@Path("ServicosADM")
public class ServicosADMController {

    @Inject
    ServicoBO servicoBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance servicosADM(List<ServicoDTO> servicos);
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance servicosADMPage() {
        List<ServicoDTO> servicos = servicoBO.listarTodos();
        return ServicosADMController.Template.servicosADM(servicos);
    }

    @POST
    @Path("cadastrar")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cadastrar(ServicoDTO dto) {
        return servicoBO.salvar(dto);
    }


    @POST
    @Path("excluir")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response excluir(ExclusaoServicoDTO dto) {
        return servicoBO.excluir(dto);
}}