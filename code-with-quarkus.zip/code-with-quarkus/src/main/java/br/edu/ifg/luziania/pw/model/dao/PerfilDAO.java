package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.dto.PerfilDTO;
import br.edu.ifg.luziania.pw.model.entity.Perfil;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;

@RequestScoped
public class PerfilDAO {

    @Inject
    EntityManager entityManager;

    public void insert(Perfil entity) {
        entityManager.persist(entity);
    }

    public void update(Perfil entity) {
        entityManager.merge(entity);
    }

    public void delete(Perfil entity) {
        entityManager.remove(entity);
    }

    public Perfil buscarPorNome(String nome) {
        //language=jpql
        String jpql = "from Perfil p where upper(trim(p.nome)) = upper(:nome)";
        List<Perfil> lista = entityManager.createQuery(jpql, Perfil.class)
                .setParameter("nome", nome.trim())
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }

    public List<PerfilDTO> listarTodos() {
        //language=jpql
        String jpql = "select new br.edu.ifg.luziania.pw.model.dto.PerfilDTO(p.id, p.nome) from Perfil p";
        return entityManager.createQuery(jpql).getResultList();
    }
}