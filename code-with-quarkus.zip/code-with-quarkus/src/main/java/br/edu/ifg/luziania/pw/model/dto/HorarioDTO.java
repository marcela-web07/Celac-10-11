package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class HorarioDTO {
    private String hora;
    private boolean disponivel;

    //construtor vazio
    public HorarioDTO() {
        hora = "";
        disponivel = true;
    }

    //construtor completo
    public HorarioDTO(String hora, boolean disponivel) {
        this.hora = hora;
        this.disponivel = disponivel;
    }

    //get e set
    public String getHora() { return hora; }
    public void setHora(String hora) { this.hora = hora; }

    public boolean isDisponivel() { return disponivel; }
    public void setDisponivel(boolean disponivel) { this.disponivel = disponivel; }
}