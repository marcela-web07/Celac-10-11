package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.AgendamentoBO;
import br.edu.ifg.luziania.pw.model.bo.LogAuditoriaBO;
import br.edu.ifg.luziania.pw.model.bo.ServicoBO;
import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.annotation.security.RolesAllowed;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

@Path("PainelADM")
@RolesAllowed("ADM")
public class PainelADMController {

    @Inject
    UsuarioBO usuarioBO;

    @Inject
    AgendamentoBO agendamentoBO;

    @Inject
    ServicoBO servicoBO;

    @Inject
    LogAuditoriaBO auditoriaBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance painelADM(
                int totalUsuarios,
                int totalAgendamentos,
                int agendamentosAtivos,
                int agendamentosCancelados,
                int totalServicos,
                int totalLogs);
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance painelADMPage() {
        return PainelADMController.Template.painelADM(
                usuarioBO.contar(),
                agendamentoBO.contar(),
                agendamentoBO.contarAtivos(),
                agendamentoBO.contarCancelados(),
                servicoBO.contar(),
                auditoriaBO.contar()
        );
    }
}