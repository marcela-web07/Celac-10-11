package br.edu.ifg.luziania.pw.model.DTO;

import jakarta.enterprise.context.ApplicationScoped;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class AgendamentoRepository {

    private final List<AgendamentoDTO> agendamentos = new ArrayList<>();

    public void salvar(AgendamentoDTO agendamento) {
        agendamentos.add(agendamento);
    }

    public List<AgendamentoDTO> listar() {
        return agendamentos;
    }
}