package br.edu.ifg.luziania.pw.model.dao;

import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import br.edu.ifg.luziania.pw.model.entity.Servico;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;

import java.util.List;

@RequestScoped
public class ServicoDAO {

    @Inject
    EntityManager entityManager;

    public void insert(Servico entity) {
        entityManager.persist(entity);
    }

    public void update(Servico entity) {
        entityManager.merge(entity);
    }

    public void delete(Servico entity) {
        entityManager.remove(entity);
    }

    public Servico buscarPorId(Integer id) {
        return entityManager.find(Servico.class, id);
    }

    public List<ServicoDTO> listarTodos() {
        //language=jpql
        String jpql = "select new br.edu.ifg.luziania.pw.model.dto.ServicoDTO(" +
                "s.id, s.nome, s.descricao, s.valor, s.duracao, s.beneficios, s.recomendacao, s.imagem) " +
                "from Servico s order by s.id";
        return entityManager.createQuery(jpql, ServicoDTO.class).getResultList();
    }

    public ServicoDTO buscarPorNome(String nome) {
        //language=jpql
        String jpql = "select new br.edu.ifg.luziania.pw.model.dto.ServicoDTO(" +
                "s.id, s.nome, s.descricao, s.valor, s.duracao, s.beneficios, s.recomendacao, s.imagem) " +
                "from Servico s where s.nome = :nome";
        List<ServicoDTO> lista = entityManager.createQuery(jpql, ServicoDTO.class)
                .setParameter("nome", nome)
                .setMaxResults(1)
                .getResultList();
        return lista.isEmpty() ? null : lista.get(0);
    }
}