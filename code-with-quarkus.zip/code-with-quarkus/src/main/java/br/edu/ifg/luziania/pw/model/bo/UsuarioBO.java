package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.PerfilDAO;
import br.edu.ifg.luziania.pw.model.dao.UsuarioDAO;
import br.edu.ifg.luziania.pw.model.dto.CadastroDTO;
import br.edu.ifg.luziania.pw.model.entity.Perfil;
import br.edu.ifg.luziania.pw.model.entity.Usuario;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;
import java.util.ArrayList;
import java.util.List;

import io.smallrye.jwt.build.Jwt;
import java.time.Duration;
import java.time.ZonedDateTime;

@RequestScoped
public class UsuarioBO {

    @Inject
    LogAuditoriaBO auditoriaBO;

    @Inject
    UsuarioDAO dao;

    @Inject
    PerfilDAO perfilDAO;


    // CADASTRO — valida salva e devolve a resposta
    @Transactional
    public Response cadastrar(String nome, String email, String senha) {
        if (nome.isEmpty() || email.isEmpty() || senha.isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        if (dao.buscarPorEmail(email) != null) {
            return Response.status(Response.Status.CONFLICT).build(); // e-mail já cadastrado
        }

        Usuario usuario = new Usuario();
        usuario.setNome(nome);
        usuario.setEmail(email);
        usuario.setSenha(senha);
        usuario.setPerfil(buscarOuCriarPerfil("CLIENTE"));

        dao.insert(usuario);
        auditoriaBO.registrar("Novo usuário cadastrado", email);
        return Response.ok().build();
    }

    // LOGIN CLIENTE
    public Response autenticar(String email, String senha) {
        Usuario usuario = buscarPorEmail(email);
        if (usuario != null && usuario.getSenha().equals(senha)) {

            auditoriaBO.registrar("Login Realizado (Cliente)", email);

            return Response.ok().header("jwt-token", gerarJWT(usuario)).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }

    // LOGIN ADM — precisa ser perfil ADM
    public Response autenticarADM(String email, String senha) {
        Usuario usuario = buscarPorEmail(email);
        if (usuario != null
                && usuario.getSenha().equals(senha)
                && usuario.getPerfil().getNome().equalsIgnoreCase("ADM")) {

            auditoriaBO.registrar("Login Realizado (ADM)", email);

            return Response.ok().header("jwt-token", gerarJWT(usuario)).build();
        }
        return Response.status(Response.Status.UNAUTHORIZED).build();
    }
    // CONFERE E-MAIL + SENHA — devolve o usuário só se for mesmo um ADM (usado pra confirmar ações perigosas)
    public Usuario validarADM(String email, String senha) {
        if (email == null || email.isEmpty() || senha == null) {
            return null;
        }
        Usuario usuario = buscarPorEmail(email);
        if (usuario != null
                && usuario.getSenha() != null
                && usuario.getSenha().equals(senha)
                && usuario.getPerfil().getNome().equalsIgnoreCase("ADM")) {
            return usuario;
        }
        return null;
    }

    private String gerarJWT(Usuario usuario) {
        return Jwt
                .issuer("http://localhost/issuer")
                .upn(usuario.getEmail())
                .groups(usuario.getPerfil().getNome().toUpperCase())
                .claim("id", usuario.getId())
                .claim("nome", usuario.getNome())
                .claim("data", ZonedDateTime.now().toString())
                .expiresIn(Duration.ofHours(1))
                .sign();
    }

    // PROMOVER
    @Transactional
    public Response promover(String email) {
        Usuario usuario = buscarPorEmail(email);
        if (usuario != null) {
            usuario.setPerfil(buscarOuCriarPerfil("ADM"));
            dao.update(usuario);
            auditoriaBO.registrar("Usuário promovido a ADM: " + email, "ADM");
        }
        return Response.ok().build();
    }

    // REBAIXAR
    @Transactional
    public Response rebaixar(String email) {
        Usuario usuario = buscarPorEmail(email);
        if (usuario != null) {
            usuario.setPerfil(buscarOuCriarPerfil("CLIENTE"));
            dao.update(usuario);
            auditoriaBO.registrar("Usuário rebaixado a Cliente: " + email, "ADM");
        }
        return Response.ok().build();
    }

    // LISTAR — igual o exemplo do professor
    public List<CadastroDTO> listar() {
        List<CadastroDTO> lista = new ArrayList<>();
        for (Usuario u : dao.listarTodos()) {
            lista.add(new CadastroDTO(u.getNome(), u.getEmail(), u.getSenha(), u.getPerfil().getNome()));
        }
        return lista;
    }

    private Usuario buscarPorEmail(String email) {
        return dao.buscarPorEmail(email);
    }

    public int contar() {
        return dao.listarTodos().size();
    }

    // busca o perfil pelo nome; se não existir ainda no banco, cria na hora
    private Perfil buscarOuCriarPerfil(String nome) {
        Perfil perfil = perfilDAO.buscarPorNome(nome);
        if (perfil != null) {
            return perfil;
        }
        Perfil novo = new Perfil();
        novo.setNome(nome);
        perfilDAO.insert(novo);
        return novo;
    }
}