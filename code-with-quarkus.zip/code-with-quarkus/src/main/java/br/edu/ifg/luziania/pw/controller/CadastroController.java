package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.UsuarioBO;
import br.edu.ifg.luziania.pw.model.dto.CadastroDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.annotation.security.PermitAll;
import jakarta.inject.Inject;
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;

@Path("Cadastro")
@PermitAll
public class CadastroController {

    @Inject
    UsuarioBO usuarioBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance cadastro();
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance cadastroPage() {
        return CadastroController.Template.cadastro();
    }


    @POST
    @Path("cadastrar")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response cadastrar(CadastroDTO dto) {
        return usuarioBO.cadastrar(dto.getNome(), dto.getEmail(), dto.getSenha());
    }
}