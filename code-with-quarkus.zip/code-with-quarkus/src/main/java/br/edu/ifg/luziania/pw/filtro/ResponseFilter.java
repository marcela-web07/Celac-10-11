package br.edu.ifg.luziania.pw.filtro;

import jakarta.ws.rs.container.ContainerRequestContext;
import jakarta.ws.rs.container.ContainerResponseContext;
import jakarta.ws.rs.core.NewCookie;
import org.jboss.resteasy.reactive.server.ServerResponseFilter;

import java.net.URI;

public class ResponseFilter {

    // Deve coincidir com mp.jwt.token.cookie em application.properties
    private static final String COOKIE_JWT = "jwt-token";

    @ServerResponseFilter
    public void responseFilter(ContainerRequestContext requisicao, ContainerResponseContext resposta) {

        // 1) login: pega o token que o BO colocou no cabeçalho e move para um cookie HttpOnly
        String token = resposta.getHeaderString("jwt-token");
        if (token != null) {
            resposta.getHeaders().remove("jwt-token");

            NewCookie cookie = new NewCookie.Builder(COOKIE_JWT)
                    .value(token)
                    .path("/")
                    .maxAge(3600)
                    .secure(false)
                    .httpOnly(true)
                    .build();

            resposta.getHeaders().add("Set-Cookie", cookie);
            return;
        }

        // 2) página sem permissão (401 ou 403): manda para o login certo
        boolean semPermissao = resposta.getStatus() == 401 || resposta.getStatus() == 403;
        String aceita = requisicao.getHeaderString("Accept");
        boolean ehPagina = "GET".equals(requisicao.getMethod()) && aceita != null && aceita.contains("text/html");

        if (semPermissao && ehPagina) {
            String caminho = requisicao.getUriInfo().getPath();
            if (caminho.startsWith("/")) {
                caminho = caminho.substring(1);
            }
            String primeiro = caminho.split("/")[0];

            // páginas de cliente vão para o login normal, as de admin para o login ADM
            boolean paginaDeCliente = "Agenda".equals(primeiro) || "MeusAgendamentos".equals(primeiro);
            String login = paginaDeCliente ? "/Login" : "/LoginADM";

            resposta.setStatus(303);
            resposta.getHeaders().remove("WWW-Authenticate");
            resposta.getHeaders().putSingle("Location", URI.create(login));
            resposta.setEntity(null);
        }
    }
}