package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.LogAuditoriaDAO;
import br.edu.ifg.luziania.pw.model.dto.LogAuditoriaDTO;
import br.edu.ifg.luziania.pw.model.entity.LogAuditoria;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@RequestScoped
public class LogAuditoriaBO {

    @Inject
    LogAuditoriaDAO dao;

    // REGISTRAR qualquer ação (genérico)
    @Transactional
    public void registrar(String acao, String usuario) {
        String dataHora = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

        LogAuditoriaDTO dto = new LogAuditoriaDTO();
        dto.setAcao(acao);
        dto.setUsuario(usuario);
        dto.setDataHora(dataHora);

        dao.insert(new LogAuditoria(dto));
    }
    // LISTAR
    public List<LogAuditoriaDTO> listar() {
        return dao.listarTodos();
    }

    public int contar() {
        return dao.listarTodos().size();
    }

    public List<LogAuditoriaDTO> ultimos() {
        List<LogAuditoriaDTO> logs = dao.listarTodos();
        int total = logs.size();
        if (total <= 3) {
            return logs;
        }
        return logs.subList(total - 3, total);
    }
}