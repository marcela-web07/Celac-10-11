package br.edu.ifg.luziania.pw.model.dto;

import jakarta.enterprise.context.ApplicationScoped;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@ApplicationScoped
public class LogAuditoriaRepository {

    private final List<LogAuditoriaDTO> logs = new ArrayList<>();

    // registra um login realizado
    public void registrarLogin(String usuario) {
        // pega a data/hora atual e formata
        String dataHora = LocalDateTime.now()
                .format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm"));

        logs.add(new LogAuditoriaDTO("Login Realizado", usuario, dataHora));
    }

    public List<LogAuditoriaDTO> listar() {
        return logs;
    }
}