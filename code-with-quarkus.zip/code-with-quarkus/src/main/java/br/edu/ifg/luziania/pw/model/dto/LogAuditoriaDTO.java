package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class LogAuditoriaDTO {
    private Integer id;
    private String acao;
    private String usuario;
    private String dataHora;

    //construtor vazio
    public LogAuditoriaDTO() {
        id = null;
        acao = "";
        usuario = "";
        dataHora = "";
    }

    //construtor completo com id (usado pela query JPQL do LogAuditoriaDAO)
    public LogAuditoriaDTO(Integer id, String acao, String usuario, String dataHora) {
        this.id = id;
        this.acao = acao;
        this.usuario = usuario;
        this.dataHora = dataHora;
    }

    //get e set
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }

    public String getAcao() { return acao; }
    public void setAcao(String acao) { this.acao = acao; }

    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }

    public String getDataHora() { return dataHora; }
    public void setDataHora(String dataHora) { this.dataHora = dataHora; }
}