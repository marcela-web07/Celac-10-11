package br.edu.ifg.luziania.pw.model.bo;

import br.edu.ifg.luziania.pw.model.dao.AgendamentoDAO;
import br.edu.ifg.luziania.pw.model.dto.AgendamentoDTO;
import br.edu.ifg.luziania.pw.model.dto.HorarioDTO;
import br.edu.ifg.luziania.pw.model.entity.Agendamento;
import jakarta.enterprise.context.RequestScoped;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import jakarta.ws.rs.core.Response;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;

@RequestScoped
public class AgendamentoBO {

    // horários de início dos procedimentos (intervalo de 2h)
    private static final List<String> HORARIOS_SEMANA =
            List.of("08:00", "10:00", "12:00", "14:00", "16:00", "18:00");
    private static final List<String> HORARIOS_SABADO =
            List.of("09:00", "11:00", "13:00");

    @Inject
    AgendamentoDAO dao;

    @Inject
    LogAuditoriaBO auditoriaBO;

    @Transactional
    public Response salvar(AgendamentoDTO dto) {
        if (dto.getProcedimento() == null || dto.getProcedimento().isEmpty()
                || dto.getData() == null || dto.getData().isEmpty()
                || dto.getHorario() == null || dto.getHorario().isEmpty()) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        // data válida, dia que a clínica abre, horário da lista e que ainda não passou
        LocalDate dataAgendada = lerData(dto.getData());
        if (dataAgendada == null
                || !horariosDoDia(dataAgendada).contains(dto.getHorario())
                || jaPassou(dataAgendada, dto.getHorario())) {
            return Response.status(Response.Status.BAD_REQUEST).build();
        }

        // outra pessoa já marcou essa data e horário
        if (dao.existeAtivo(dto.getData(), dto.getHorario(), dto.getId())) {
            return Response.status(Response.Status.CONFLICT).build();
        }

        Agendamento entity = new Agendamento(dto);

        if (entity.getId() == null) {
            dao.insert(entity);
            dto.setId(entity.getId());
            auditoriaBO.registrar("Agendamento realizado: " + entity.getProcedimento(),
                    entity.getEmailUsuario());
        } else {
            dao.update(entity);
            auditoriaBO.registrar("Agendamento atualizado: " + entity.getProcedimento(),
                    entity.getEmailUsuario());
        }

        return Response.ok(dto).build();
    }

    // HORÁRIOS DO DIA — devolve cada horário e se ainda está livre
    public List<HorarioDTO> listarHorarios(String dataTexto) {
        List<HorarioDTO> lista = new ArrayList<>();

        LocalDate data = lerData(dataTexto);
        if (data == null) {
            return lista;
        }

        List<String> ocupados = dao.listarHorariosOcupados(dataTexto);
        for (String hora : horariosDoDia(data)) {
            boolean livre = !ocupados.contains(hora) && !jaPassou(data, hora);
            lista.add(new HorarioDTO(hora, livre));
        }
        return lista;
    }

    // segunda a sexta: 08h às 20h | sábado: 09h às 14h | domingo: fechado
    private List<String> horariosDoDia(LocalDate data) {
        DayOfWeek dia = data.getDayOfWeek();
        if (dia == DayOfWeek.SUNDAY) {
            return List.of();
        }
        if (dia == DayOfWeek.SATURDAY) {
            return HORARIOS_SABADO;
        }
        return HORARIOS_SEMANA;
    }

    private LocalDate lerData(String texto) {
        try {
            return LocalDate.parse(texto);
        } catch (DateTimeParseException | NullPointerException e) {
            return null;
        }
    }

    private boolean jaPassou(LocalDate data, String hora) {
        LocalDateTime momento = LocalDateTime.of(data, LocalTime.parse(hora));
        return momento.isBefore(LocalDateTime.now(ZoneId.of("America/Sao_Paulo")));
    }

    public int contar() {
        return dao.listarTodos().size();
    }
    public int contarAtivos() {
        return (int) dao.listarTodos().stream()
                .filter(a -> "ATIVO".equals(a.getStatus()))
                .count();
    }

    public int contarCancelados() {
        return (int) dao.listarTodos().stream()
                .filter(a -> "CANCELADO".equals(a.getStatus()))
                .count();
    }

    public Response listar() {
        List<AgendamentoDTO> lista = dao.listarTodos();
        return Response.ok(lista).build();
    }

    public List<AgendamentoDTO> listarTodos() {
        return dao.listarTodos();
    }

    public List<AgendamentoDTO> listarPorEmail(String email) {
        return dao.listarPorEmail(email);
    }

    public List<AgendamentoDTO> ultimos() {
        List<AgendamentoDTO> lista = dao.listarTodos();
        int total = lista.size();
        if (total <= 3) {
            return lista;
        }
        return lista.subList(total - 3, total);
    }

    @Transactional
    public Response cancelar(Integer id) {
        Agendamento entity = dao.buscarPorId(id);
        if (entity == null) {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
        entity.setStatus("CANCELADO");
        dao.update(entity);
        auditoriaBO.registrar("Agendamento cancelado: " + entity.getProcedimento(),
                entity.getEmailUsuario());
        return Response.ok().build();
    }
}