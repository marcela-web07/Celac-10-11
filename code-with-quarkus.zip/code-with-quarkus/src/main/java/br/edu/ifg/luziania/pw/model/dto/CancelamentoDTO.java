package br.edu.ifg.luziania.pw.model.dto;

public class CancelamentoDTO {
    private Integer id;

    public CancelamentoDTO() {
        id = null;
    }

    public CancelamentoDTO(Integer id) {
        this.id = id;
    }

    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
}