package br.edu.ifg.luziania.pw.model.entity;

import br.edu.ifg.luziania.pw.model.dto.PerfilDTO;
import jakarta.persistence.*;

@Entity
@Table(name = "perfil")
public class Perfil {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    private String nome;

    // construtor vazio (obrigatório pro ORM)
    public Perfil() {
    }

    // construtor que recebe o DTO (transforma DTO em entidade)
    public Perfil(PerfilDTO dto) {
        this.id = dto.getId();
        this.nome = dto.getNome();
    }

    // getters e setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}