package br.edu.ifg.luziania.pw.controller;

import br.edu.ifg.luziania.pw.model.bo.ServicoBO;
import br.edu.ifg.luziania.pw.model.dto.ServicoDTO;
import io.quarkus.qute.CheckedTemplate;
import io.quarkus.qute.TemplateInstance;
import jakarta.inject.Inject;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.core.MediaType;

import java.util.List;

@Path("/")
public class IndexController {

    @Inject
    ServicoBO servicoBO;

    @CheckedTemplate
    public static class Template {
        public static native TemplateInstance index(List<ServicoDTO> servicos);
    }

    @GET
    @Produces(MediaType.TEXT_HTML)
    public TemplateInstance indexpage() {
        List<ServicoDTO> servicos = servicoBO.listarTodos();
        return IndexController.Template.index(servicos);
    }
}