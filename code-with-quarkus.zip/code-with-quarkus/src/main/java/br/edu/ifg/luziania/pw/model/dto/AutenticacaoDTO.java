package br.edu.ifg.luziania.pw.model.dto;

//atributos
public class AutenticacaoDTO {
    private String identificador;
    private String senha;
//construtor vazio
    public AutenticacaoDTO() {
        identificador = "";
        senha = "";
    }
//construtor completo
    public AutenticacaoDTO(String identificador, String senha) {
        this.identificador = identificador;
        this.senha = senha;
    }

//get e set
    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public String getIdentificador() {
        return identificador;
    }

    public void setIdentificador(String identificador) {
        this.identificador = identificador;
    }
}
