function confirmarAgendamento() {
    const data = document.getElementById('data').value;
    const hora = document.getElementById('hora').value;

    if (data === "" || hora === "") {
        alert("Por favor, selecione a data e o horário antes de confirmar.");
    } else {
        const meuModal = document.getElementById('modalSucesso');
        meuModal.style.setProperty('display', 'flex', 'important');
    }
}

function fecharEVoltar() {
    window.location.href = "/Home";
}

function fazerLoginAdm() {
    const id = document.getElementById('idAdm').value;
    const senha = document.getElementById('senhaAdm').value;
    if (id === "" || senha === "") {
        alert("Erro: ID e Senha são obrigatórios!");
    } else {
        alert("Validando dados no sistema...");
        // Aqui o Java entrará em ação para conferir se estão certos
        window.location.href = "/PainelADM";
    }
}

function fazerLogin() {
    const email = document.getElementById('email').value;
    const id = document.getElementById('senha').value;
    if (id === "" || senha === "") {
        alert("Erro: Email e Senha são obrigatórios!");
    } else {
        alert("Acessando painel de serviços");
        // Aqui o Java entrará em ação para conferir se estão certos
        window.location.href = "/Home";
    }
}

function realizarCadastro() {
    const nome = document.getElementById('nome').value.trim();
    const email = document.getElementById('email').value.trim();
    const senha = document.getElementById('senha').value.trim();

    if (nome === "" || email === "" || senha === "") {
        alert("Atenção: Todos os campos de cadastro são obrigatórios!");
    } else {
        // Simula o salvamento
        alert("Cadastro realizado! Agora você já pode fazer seu login.");
        window.location.href = "/Login";
    }
}
