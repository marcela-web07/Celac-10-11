var autenticacaoDTO = {
    email: "",
    senha: ""
}

function autenticar () {

    autenticacaoDTO.email = document.getElementById("email").value;
    autenticacaoDTO.email = document.getElementById("password").value;

    var url= 'http://localhost:8080/autenticar';
    var configrequest = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(autenticacaoDTO)
    };

fetch(url, configRequest)
    .then(function (responce) {
        if (responce.ok) {
            console.log ("Dados enviados com sucesso!")
            window.location.href = '/home'
        } else {
            console.log("Falha ao enviar dados!");
        }
})
    .catch(function (error) {
        console.error(error);
    })
}