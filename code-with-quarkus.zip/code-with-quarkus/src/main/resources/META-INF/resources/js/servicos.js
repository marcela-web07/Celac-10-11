document.querySelectorAll(".servico-preco").forEach(function (el) {
    var valor = parseFloat(el.dataset.valor);
    if (isNaN(valor)) {
        el.textContent = "";
        return;
    }
    el.textContent = valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
});