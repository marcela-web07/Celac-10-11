var cadastroDTO = {
    nome: "",
    email: "",
    senha: ""
}
function cadastrar() {

    var nome = document.getElementById("nome").value;
    var email = document.getElementById("email").value;
    var senha = document.getElementById("senha").value;

    // valida se está tudo preenchido ANTES de enviar
    if (nome === "" || email === "" || senha === "") {
        alert("Preencha todos os campos!");
        return;
    }

    var cadastroDTO = {
        nome: nome,
        email: email,
        senha: senha
    };

    var url = 'http://localhost:8080/Cadastro/cadastrar';
    var configrequest = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(cadastroDTO)
    };

    fetch(url, configrequest)
        .then(function (responce) {
            if (responce.ok) {
                window.location.href = '/Login';
            } else {
                alert("Erro ao cadastrar!");
            }
        })
        .catch(function (error) {
            console.error(error);
        });
}
