
function voltarHome() {
    window.location.href = "index.html";
}

// Futuramente, aqui você pode criar funções para carregar os dados
// que virão do seu Java (Agendamento.java e LogAutoria.java)
console.log("Painel Administrativo carregado com sucesso.");