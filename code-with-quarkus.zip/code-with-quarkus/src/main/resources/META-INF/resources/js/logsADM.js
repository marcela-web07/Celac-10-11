// Descobre o "tipo" de uma ação pelo texto que o BO gravou
function classificar(acao) {
    const a = acao.toLowerCase();
    if (a.startsWith("login")) return "login";
    if (a.startsWith("agendamento cancelado")) return "cancelamento";
    if (a.startsWith("agendamento")) return "agendamento";
    if (a.startsWith("serviço") || a.startsWith("servico")) return "servico";
    if (a.startsWith("novo usuário") || a.startsWith("novo usuario")) return "cadastro";
    if (a.includes("promovido") || a.includes("rebaixado")) return "admin";
    return "outro";
}

const tbody = document.querySelector("#tabelaLogs tbody");
const selectTipo = document.getElementById("filtroTipo");
const inputBusca = document.getElementById("filtroBusca");

// Mais recente primeiro: inverte a ordem das linhas que o Qute renderizou
const linhas = Array.from(tbody.querySelectorAll("tr")).reverse();
linhas.forEach(function (tr) {
    tbody.appendChild(tr);
    const badge = tr.querySelector(".badge");
    const tipo = classificar(badge.textContent.trim());
    tr.dataset.tipo = tipo;
    badge.classList.add(tipo);
});

// Números dos cards
function atualizarCards() {
    const contar = function (tipo) {
        return linhas.filter(function (tr) { return tr.dataset.tipo === tipo; }).length;
    };
    document.getElementById("cTotal").textContent = linhas.length;
    document.getElementById("cLogin").textContent = contar("login");
    document.getElementById("cAgendamento").textContent = contar("agendamento");
    document.getElementById("cCancelamento").textContent = contar("cancelamento");
    document.getElementById("cServico").textContent = contar("servico");
}

// Aplica filtro de tipo + busca
function filtrar() {
    const tipo = selectTipo.value;
    const busca = inputBusca.value.trim().toLowerCase();
    let visiveis = 0;

    linhas.forEach(function (tr) {
        const okTipo = (tipo === "todos") || (tr.dataset.tipo === tipo);
        const okBusca = tr.textContent.toLowerCase().includes(busca);
        const mostrar = okTipo && okBusca;
        tr.classList.toggle("oculta", !mostrar);
        if (mostrar) visiveis++;
    });

    document.getElementById("contador").textContent =
        "Mostrando " + visiveis + " de " + linhas.length + " registros";
    document.getElementById("vazio").style.display = visiveis === 0 ? "block" : "none";

    // destaca o card do tipo selecionado
    document.querySelectorAll(".mini-card.clicavel").forEach(function (card) {
        card.classList.toggle("ativo", card.dataset.filtro === tipo);
    });
}

// Eventos
selectTipo.addEventListener("change", filtrar);
inputBusca.addEventListener("input", filtrar);

document.getElementById("btnLimpar").addEventListener("click", function () {
    selectTipo.value = "todos";
    inputBusca.value = "";
    filtrar();
});

document.querySelectorAll(".mini-card.clicavel").forEach(function (card) {
    card.addEventListener("click", function () {
        selectTipo.value = card.dataset.filtro;
        filtrar();
    });
});

atualizarCards();
filtrar();