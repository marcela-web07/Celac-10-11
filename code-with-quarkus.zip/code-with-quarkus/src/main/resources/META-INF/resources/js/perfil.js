var perfilDTO = { id: null, nome: "" }

function salvar() {
    perfilDTO.nome = document.getElementById("nome").value;

    var url = 'http://localhost:8080/Perfil/salvar';
    var configRequest = {
        method: 'POST',
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' },
        body: JSON.stringify(perfilDTO)
    };

    fetch(url, configRequest)
        .then(function (r) {
            if (r.ok) {
                document.getElementById("nome").value = "";
                listar();
            } else {
                alert("Falha ao salvar.");
            }
        })
        .catch(function (e) { console.error(e); });
}

function listar() {
    fetch('http://localhost:8080/Perfil/listar', {
        method: 'GET',
        headers: { 'Accept': 'application/json', 'Content-Type': 'application/json' }
    })
        .then(function (r) { return r.json(); })
        .then(function (data) { popularLista(data); })
        .catch(function (e) { console.error(e); });
}

function popularLista(lista) {
    var tabela = document.getElementById('tabela-corpo');
    tabela.innerHTML = "";
    lista.forEach(function (el) {
        tabela.innerHTML += "<tr><td>" + el.id + "</td><td>" + el.nome + "</td></tr>";
    });
}

window.onload = listar;