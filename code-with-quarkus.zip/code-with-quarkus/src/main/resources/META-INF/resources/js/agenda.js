var agendamentoDTO = {
    paciente: "",
    procedimento: "",
    data: "",
    horario: "",
    observacoes: ""
}

window.onload = function () {
    // não deixa escolher uma data que já passou
    document.getElementById("data").min = hojeTexto();

    var params = new URLSearchParams(window.location.search);
    var nome = params.get("procedimento");
    if (!nome) {
        return;
    }

    document.getElementById("nomeProcedimento").textContent = nome;
    document.getElementById("procedimento").value = nome;

    fetch("/ServicoDetalhe?nome=" + encodeURIComponent(nome))
        .then(function (resposta) {
            return resposta.ok ? resposta.json() : null;
        })
        .then(function (s) {
            if (s) {
                mostrarInfo(s);
            }
        })
        .catch(function (erro) {
            console.error(erro);
        });
};

// data de hoje no formato aaaa-mm-dd
function hojeTexto() {
    var d = new Date();
    var mes = String(d.getMonth() + 1).padStart(2, "0");
    var dia = String(d.getDate()).padStart(2, "0");
    return d.getFullYear() + "-" + mes + "-" + dia;
}

// chamada quando a pessoa escolhe a data: busca no servidor os horários do dia
function carregarHorarios() {
    var data = document.getElementById("data").value;
    var select = document.getElementById("horario");
    var aviso = document.getElementById("avisoHorario");

    select.innerHTML = '<option value="">Escolha a data primeiro</option>';
    aviso.textContent = "";

    if (data === "") {
        return;
    }

    var partes = data.split("-");
    var diaSemana = new Date(partes[0], partes[1] - 1, partes[2]).getDay(); // 0 = domingo, 6 = sábado

    if (diaSemana === 0) {
        document.getElementById("data").value = "";
        aviso.textContent = "A clínica não funciona aos domingos. Escolha outro dia.";
        return;
    }

    aviso.textContent = diaSemana === 6
        ? "Sábado: atendimento das 09:00 às 14:00."
        : "Segunda a sexta: atendimento das 08:00 às 20:00.";

    fetch("/Agenda/horarios?data=" + encodeURIComponent(data))
        .then(function (resposta) {
            return resposta.ok ? resposta.json() : [];
        })
        .then(function (lista) {
            select.innerHTML = '<option value="">Selecione o horário</option>';
            var livres = 0;

            lista.forEach(function (h) {
                var opcao = document.createElement("option");
                opcao.value = h.hora;
                opcao.textContent = h.disponivel ? h.hora : h.hora + " (indisponível)";
                opcao.disabled = !h.disponivel;
                select.appendChild(opcao);
                if (h.disponivel) {
                    livres++;
                }
            });

            if (livres === 0) {
                aviso.textContent = "Não há horários livres nesse dia. Escolha outra data.";
            }
        })
        .catch(function (erro) {
            console.error(erro);
        });
}

function preencherBox(boxId, textoId, texto) {
    var box = document.getElementById(boxId);
    if (texto) {
        document.getElementById(textoId).textContent = texto;
        box.style.display = "block";
    } else {
        box.style.display = "none";
    }
}

// mostra preço, duração, benefícios e recomendação (sem a descrição longa)
function mostrarInfo(s) {
    var preco = document.getElementById("infoPreco");
    if (s.valor && s.valor > 0) {
        preco.textContent = s.valor.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
        preco.style.display = "block";
    } else {
        preco.style.display = "none";
    }

    preencherBox("boxDuracao", "infoDuracao", s.duracao);
    preencherBox("boxBeneficios", "infoBeneficios", s.beneficios);
    preencherBox("boxRecomendacao", "infoRecomendacao", s.recomendacao);
}

function agendar() {

    var paciente = document.getElementById("paciente").value;
    var procedimento = document.getElementById("procedimento").value;
    var data = document.getElementById("data").value;
    var horario = document.getElementById("horario").value;
    var observacoes = document.getElementById("observacoes").value;

    if (paciente === "" || procedimento === "" || data === "" || horario === "") {
        alert("Preencha data e horário!");
        return;
    }

    agendamentoDTO.paciente = paciente;
    agendamentoDTO.procedimento = procedimento;
    agendamentoDTO.data = data;
    agendamentoDTO.horario = horario;
    agendamentoDTO.observacoes = observacoes;

    agendamentoDTO.emailUsuario = sessionStorage.getItem("emailLogado");
    var url = 'http://localhost:8080/Agenda/agendar';
    var configrequest = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(agendamentoDTO)
    };

    fetch(url, configrequest)
        .then(function (responce) {
            if (responce.ok) {
                alert("Agendamento confirmado!");
                window.location.href = '/Home';
            } else if (responce.status === 409) {
                alert("Esse horário acabou de ser ocupado por outra pessoa. Escolha outro.");
                carregarHorarios();
            } else if (responce.status === 400) {
                alert("Data ou horário inválido. A clínica atende de segunda a sábado, nos horários da lista.");
                carregarHorarios();
            } else {
                alert("Erro ao agendar. Tente novamente.");
            }
        })
        .catch(function (error) {
            console.error(error);
        });
}