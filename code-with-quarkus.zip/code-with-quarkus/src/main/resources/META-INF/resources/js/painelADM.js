// Data
const agora = new Date();

document.getElementById("heroData").textContent = agora.toLocaleDateString("pt-BR", {
    weekday: "long", day: "numeric", month: "long", year: "numeric"
});

// Números aparecem direto, sem animação
document.querySelectorAll(".stat-numero").forEach(function (el) {
    el.textContent = el.dataset.valor;
});

// Barra ativos x cancelados
const situacao = document.getElementById("situacao");
const ativos = parseInt(situacao.dataset.ativos, 10) || 0;
const cancelados = parseInt(situacao.dataset.cancelados, 10) || 0;
const total = ativos + cancelados;

const pctAtivos = total === 0 ? 0 : Math.round((ativos / total) * 100);
const pctCancelados = total === 0 ? 0 : 100 - pctAtivos;

document.getElementById("pctAtivos").textContent = pctAtivos + "%";
document.getElementById("pctCancelados").textContent = pctCancelados + "%";

// pequeno atraso para a animação da barra aparecer
setTimeout(function () {
    document.getElementById("barraAtivos").style.width = pctAtivos + "%";
    document.getElementById("barraCancelados").style.width = pctCancelados + "%";
}, 200);