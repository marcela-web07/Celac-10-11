var autenticacaoDTO = {
    identificador: "",
    senha: ""
}

function autenticar() {
    autenticacaoDTO.identificador = document.getElementById("idAdm").value;
    autenticacaoDTO.senha = document.getElementById("senhaAdm").value;

    var url = 'http://localhost:8080/LoginADM/autenticar';
    var configrequest = {
        method: 'POST',
        headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(autenticacaoDTO)
    };

    fetch(url, configrequest)
        .then(function (responce) {
            if (responce.ok) {
                window.location.href = '/PainelADM';
            } else {
                alert("Acesso negado! Você não tem permissão de administrador.");  // ← adiciona isto
            }
        })
        .catch(function (error) {
            console.error(error);
        });
}
function voltarHome() {
    window.location.href = "/";
}