var imagemBase64 = "";

function ler(id) {
    var el = document.getElementById(id);
    return el ? el.value : "";
}

// mostra o preço formatado na tabela (R$ 80,00)
document.querySelectorAll("tr[data-id]").forEach(function (tr) {
    var v = parseFloat(tr.dataset.valor);
    tr.querySelector(".col-valor").textContent = isNaN(v) || v === 0
        ? "—"
        : v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
});

// lê a foto escolhida, reduz para no máximo 700px e guarda como texto
function escolherFoto(input) {
    var arquivo = input.files[0];
    if (!arquivo) {
        imagemBase64 = "";
        return;
    }

    var leitor = new FileReader();
    leitor.onload = function (e) {
        var img = new Image();
        img.onload = function () {
            var max = 700;
            var escala = Math.min(1, max / Math.max(img.width, img.height));
            var canvas = document.createElement("canvas");
            canvas.width = Math.round(img.width * escala);
            canvas.height = Math.round(img.height * escala);

            var ctx = canvas.getContext("2d");
            ctx.fillStyle = "#ffffff";
            ctx.fillRect(0, 0, canvas.width, canvas.height);
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);

            imagemBase64 = canvas.toDataURL("image/jpeg", 0.8);

            var preview = document.getElementById("previewFoto");
            preview.src = imagemBase64;
            preview.style.display = "block";
        };
        img.src = e.target.result;
    };
    leitor.readAsDataURL(arquivo);
}

// joga os dados da linha no formulário
function editarServico(botao) {
    var tr = botao.closest("tr");

    document.getElementById("id").value = tr.dataset.id;
    document.getElementById("nome").value = tr.dataset.nome;
    document.getElementById("valor").value = tr.dataset.valor;
    document.getElementById("duracao").value = tr.dataset.duracao;
    document.getElementById("beneficios").value = tr.dataset.beneficios;
    document.getElementById("recomendacao").value = tr.dataset.recomendacao;
    document.getElementById("descricao").value = tr.dataset.descricao;

    // foto: mostra a atual; só será trocada se escolher outra
    imagemBase64 = "";
    document.getElementById("foto").value = "";
    var preview = document.getElementById("previewFoto");
    var mini = tr.querySelector("img.miniatura");
    if (mini) {
        preview.src = mini.src;
        preview.style.display = "block";
    } else {
        preview.style.display = "none";
    }

    document.getElementById("tituloForm").textContent = "Editando: " + tr.dataset.nome;
    document.getElementById("btnSalvar").textContent = "Salvar alterações";
    document.getElementById("btnCancelar").style.display = "inline-block";

    document.getElementById("areaForm").scrollIntoView({ behavior: "smooth" });
}

function cancelarEdicao() {
    window.location.reload();
}

async function cadastrarServico() {
    var valor = parseFloat(ler("valor"));
    if (isNaN(valor)) {
        valor = 0;
    }

    var idTexto = ler("id");

    var servicoDTO = {
        id: idTexto === "" ? null : parseInt(idTexto, 10),
        nome: ler("nome"),
        descricao: ler("descricao"),
        valor: valor,
        duracao: ler("duracao"),
        beneficios: ler("beneficios"),
        recomendacao: ler("recomendacao"),
        imagem: imagemBase64
    };

    try {
        var response = await fetch("/ServicosADM/cadastrar", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(servicoDTO)
        });

        if (response.ok) {
            alert(servicoDTO.id === null ? "Serviço cadastrado com sucesso!" : "Serviço atualizado com sucesso!");
            window.location.reload();
        } else {
            alert("Erro ao salvar serviço (código " + response.status + ").");
        }
    } catch (error) {
        alert("Erro de conexão: " + error);
    }
}
// ---------- EXCLUIR SERVIÇO (pede ID e senha de um ADM) ----------
function abrirModalExcluir(botao) {
    var tr = botao.closest("tr");

    document.getElementById("idServicoExcluir").value = tr.dataset.id;
    document.getElementById("nomeServicoExcluir").textContent = tr.dataset.nome;
    document.getElementById("adminEmail").value = "";
    document.getElementById("adminSenha").value = "";
    document.getElementById("erroExcluir").textContent = "";

    document.getElementById("modalExcluir").classList.add("aberto");
    document.getElementById("adminEmail").focus();
}

function fecharModalExcluir() {
    document.getElementById("modalExcluir").classList.remove("aberto");
    document.getElementById("adminSenha").value = "";
}

async function confirmarExclusao() {
    var erro = document.getElementById("erroExcluir");
    var email = ler("adminEmail").trim();
    var senha = ler("adminSenha");

    if (email === "" || senha === "") {
        erro.textContent = "Informe o e-mail e a senha do administrador.";
        return;
    }

    var exclusaoDTO = {
        servicoId: parseInt(ler("idServicoExcluir"), 10),
        adminEmail: email,
        senha: senha
    };

    try {
        var response = await fetch("/ServicosADM/excluir", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(exclusaoDTO)
        });

        if (response.ok) {
            alert("Serviço excluído com sucesso!");
            window.location.reload();
        } else if (response.status === 401) {
            erro.textContent = "E-mail ou senha inválidos, ou esse usuário não é administrador.";
            document.getElementById("adminSenha").value = "";
        } else if (response.status === 404) {
            alert("Esse serviço não existe mais.");
            window.location.reload();
        } else {
            erro.textContent = "Erro ao excluir serviço (código " + response.status + ").";
        }
    } catch (error) {
        erro.textContent = "Erro de conexão: " + error;
    }
}

// Enter confirma, Esc cancela
document.addEventListener("keydown", function (e) {
    var aberto = document.getElementById("modalExcluir").classList.contains("aberto");
    if (!aberto) {
        return;
    }
    if (e.key === "Escape") {
        fecharModalExcluir();
    } else if (e.key === "Enter") {
        confirmarExclusao();
    }
});